var nomes = [
    {id: 1, nome: 'juca', sobrenome: 'da silva', idade: 42},
    {id: 2, nome: 'daniel', sobrenome: 'gonçalves',  idade: 21},
    {id:3, nome: 'matheus', sobrenome: 'garcia', idade: 28},
    {id: 4, nome: 'gabriel', sobrenome: 'pinheiro',  idade: 21}
];
 function primeiraLetra(){ 
   for(var i=0;nomes.length>i;i++){
     var inicio= "Olá,"
     var aumentar= nomes[i].nome;
     var sobre =nomes[i].sobrenome;
     var saida=aumentar.replace(/^./, aumentar[0].toUpperCase());
     var final= inicio+" "+saida+" "+ sobre;
     console.log(final);
     }
   }
primeiraLetra(nomes);