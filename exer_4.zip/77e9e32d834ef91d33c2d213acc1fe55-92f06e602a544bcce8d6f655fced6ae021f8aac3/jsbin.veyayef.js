var troca ='teste 1 de 2 string 3';
var resposta = troca.replace(/1|2|3/g,"[removido]")
console.log(resposta);