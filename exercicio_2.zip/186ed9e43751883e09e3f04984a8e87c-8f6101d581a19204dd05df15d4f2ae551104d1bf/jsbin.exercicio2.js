function saudacoes(nome){
  return "Olá," + nome;
}
function aplica(saudacoes,nome1,nome2){
 console.log(saudacoes(nome1));
  console.log(saudacoes(nome2));
}
var nome1 = prompt("informe seu nome","");
var nome2 = prompt("informe proximo nome","");

var returned = aplica(saudacoes,nome1,nome2);