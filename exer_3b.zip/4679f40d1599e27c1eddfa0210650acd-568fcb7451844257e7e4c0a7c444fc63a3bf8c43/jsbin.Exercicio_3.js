function imprimeTudo(){
  return "textos inseridos"+arguments;
}
var palavras=[];
var i=0;
var verifica="q";
do{
  palavras[i]=prompt("informe a string","");
  verifica=palavras[i];
  i++;
}while(verifica!=="quero sair");
imprimeTudo(palavras);