var dicionario= {4: 'a', 3: 'e', 1: 'i', 5: 's'};
var entrada ='T35t3 d3 35t4g1o';
var saida = entrada.replace(/[1-5]/g,m => dicionario[m]);
console.log(saida);