//funcao que retorna a mais longa de duas strings, retorna a segunda caso tenham mesmo comprimento
function maiorString(primeiraString, segundaString){
   if(primeiraString.length>segundaString.length)
     return primeiraString;
     else{
       return segundaString;
     }
}
var primeiraString = prompt("Informe primeira string","primeira");
var segundaString = prompt("Informe segunda string","segunda");

console.log(maiorString(primeiraString,segundaString));