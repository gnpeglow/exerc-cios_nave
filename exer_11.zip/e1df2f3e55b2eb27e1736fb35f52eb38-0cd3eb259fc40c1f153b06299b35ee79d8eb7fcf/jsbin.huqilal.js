var nomes = [
    {id: 1, nome: 'juca', sobrenome: 'da silva', idade: 42},
    {id: 2, nome: 'daniel', sobrenome: 'gonçalves',  idade: 21},
    {id:3, nome: 'matheus', sobrenome: 'garcia', idade: 28},
    {id: 4, nome: 'gabriel', sobrenome: 'pinheiro',  idade: 21}
];
function troca(i){
  var aux= nomes[i];
  nomes[i]=nomes[i+1];
  nomes[i+1]=aux;
}
for(var i=0; i<nomes.length-1; i++){//for
  if(nomes[i].idade<nomes[i+1].idade){//if1
    troca(i);
  }//if1 fim
  if(nomes[i].idade==nomes[i+1].idade){//if2
    if(nomes[i].id<nomes[i+1].id){//if3
      troca(i)
    }//if2 fim
  }//if3 fim
 }//for fim
console.log(nomes);