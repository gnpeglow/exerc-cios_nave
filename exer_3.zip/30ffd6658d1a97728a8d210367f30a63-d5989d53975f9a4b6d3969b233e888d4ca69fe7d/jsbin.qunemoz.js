function imprimeTudo(){
  console.log(arguments);
}
imprimeTudo("a","ab","aaa","teste","a89")